import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys


WebUI.openBrowser('')


WebUI.navigateToUrl('https://page-rhythm-front-end.onrender.com/landing-page')

String email = 'nguyenvanmuoi@gmail.com'
WebUI.setText(findTestObject('Object Repository/UC08_UI04/Page_PageRhythm/input_Login to continue_landing-page-input-info'), email)

WebUI.setEncryptedText(findTestObject('Object Repository/UC04_UI01/Page_PageRhythm/input_Login to continue_password-input'),
    '8SQVv/p9jVTqW8DV17zZxg==')


WebUI.click(findTestObject('Object Repository/UC04_UI01/Page_PageRhythm/button_Login'))


WebUI.click(findTestObject('Object Repository/UC04_UI01/Page_PageRhythm/h3_Learn Flask I'))


WebUI.click(findTestObject('Object Repository/UC04_UI01/Page_PageRhythm/button_Write a comment'))

String comment = 'What\'s a great book'
WebUI.setText(findTestObject('Object Repository/UC04_UI01/Page_PageRhythm/textarea_Whats a great book'), comment)

WebUI.click(findTestObject('Object Repository/UC04_UI01/Page_PageRhythm/button_Submit'))


WebUI.click(findTestObject('Object Repository/UC04_UI01/Page_PageRhythm/div_Whats a great book'))

WebUI.closeBrowser()